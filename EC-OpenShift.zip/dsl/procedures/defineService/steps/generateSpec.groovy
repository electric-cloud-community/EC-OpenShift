
// Gather input parameters
def serviceName = $[serviceName]

// The following information will be retrieved from the Deploy container instance
//imageName: Docker image name. Use image-name:version-tag format to refer to a specific version of the image.
//ports
//env variables
//entry point

