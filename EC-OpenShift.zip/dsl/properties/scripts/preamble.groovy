$[/plugins/EC-Kubernetes/project/scripts/Logger]
$[/plugins/EC-Kubernetes/project/scripts/BaseClient]
$[/plugins/EC-Kubernetes/project/scripts/EFClient]
$[/plugins/EC-Kubernetes/project/scripts/KubernetesClient]

$[/myProject/scripts/OpenShiftClient]