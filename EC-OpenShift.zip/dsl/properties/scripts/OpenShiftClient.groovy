
public class OpenShiftClient extends KubernetesClient {

}